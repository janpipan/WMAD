package publisher;

import util.Message;

public interface Publisher {
  
    public void publish(Message message);
}
