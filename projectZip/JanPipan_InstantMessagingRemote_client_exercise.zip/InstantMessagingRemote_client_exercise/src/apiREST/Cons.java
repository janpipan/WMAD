package apiREST;

/**
 *
 * @author juanluis
 */
public interface Cons {
  
  String SERVER_REST = "http://localhost:8080/InstantMessagingRemote_server_exercise/rest";
  String SERVER_WEBSOCKET = "ws://localhost:8080/InstantMessagingRemote_server_exercise/ws";
  
}
