package util;

/**
 *
 * @author upcnet
 */
public class Login_check {
  
  public String login;
  public String password;
  
}
