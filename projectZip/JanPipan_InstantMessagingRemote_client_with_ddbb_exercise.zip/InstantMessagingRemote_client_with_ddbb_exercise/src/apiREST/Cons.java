/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apiREST;

/**
 *
 * @author juanluis
 */
public interface Cons {
  
  String SERVER_REST = "http://localhost:8080/InstantMessagingRemote_server_with_ddbb_exercise/webresources";
  String SERVER_WEBSOCKET = "ws://localhost:8080/InstantMessagingRemote_server_with_ddbb_exercise/ws";
  
}
